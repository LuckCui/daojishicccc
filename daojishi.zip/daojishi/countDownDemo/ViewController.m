//
//  ViewController.m
//  countDownDemo
//
//  Created by 崔坚州 on 15/12/8.
//  Copyright © 2015年 czebd. All rights reserved.
//

#import "ViewController.h"
#import "CZCountDownView.h"
@interface ViewController (){
    // 定时器
    NSTimer *timer;
    // 总得秒数（时间戳）
    NSInteger ms;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CZCountDownView *countDown = [CZCountDownView shareCountDown];
    countDown.frame = CGRectMake(100, 100, 200, 30);
    countDown.timestamp = 10;//时间戳
    countDown.backgroundImageName = @"search_k";
    countDown.timerStopBlock = ^{
        NSLog(@"时间停止");
    };
    [self.view addSubview:countDown];
    
}

-(void)timer:(NSTimer*)timerr{
    ms--;
    NSInteger ss = 1;
    NSInteger mi = ss * 60;
    NSInteger hh = mi * 60;
    NSInteger dd = hh * 24;
    
    // 剩余的
    NSInteger day = ms / dd;// 天
    NSInteger hour = (ms - day * dd) / hh;// 时
    NSInteger minute = (ms - day * dd - hour * hh) / mi;// 分
    NSInteger second = (ms - day * dd - hour * hh - minute * mi) / ss;// 秒
    NSLog(@"%zd日:%zd时:%zd分:%zd秒",day,hour,minute,second);
}


- (void)dealloc{
    if (ms == 0) {
        [timer invalidate];
        timer = nil;
    }
}

@end
